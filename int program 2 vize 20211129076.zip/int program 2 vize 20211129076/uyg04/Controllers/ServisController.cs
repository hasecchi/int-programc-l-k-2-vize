﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace uyg04.Controllers
{
    public class ServisController : ApiController
    {
    }
}
